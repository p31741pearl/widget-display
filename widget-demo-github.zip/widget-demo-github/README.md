# Widget Clamp Demo

互動式 chat widget 尺寸設計 demo,展示：

- Widget 尺寸(S/M/L)只決定收合泡泡大小,展開後視窗統一用同一套 clamp() 公式,確保任何檔位、任何螢幕尺寸都不會破版
- Offset X/Y 可獨立客製化左右/上下邊距
- 展開後關閉按鈕可選擇固定 60px,或跟隨收合泡泡尺寸,並可切換是否要有尺寸漸變動畫
- Header 頭像、歡迎卡片頭像、訊息頭像皆依比例跟隨 Widget 尺寸自動縮放
- 點擊展開後會先進入歡迎頁面,點擊「開始對話」才切換到聊天畫面,歡迎頁面內容過長時可上下捲動
- 左側「模擬螢幕尺寸」用來測試不同螢幕寬高下是否會破版

## 部署到 GitHub Pages

1. 建立一個新的 GitHub repository(需為 Public,GitHub Pages 免費方案僅支援 public repo)
2. 把這個資料夾裡的 `index.html` 上傳到 repo 根目錄
3. 到 repo 的 **Settings → Pages**
4. Source 選擇 `main` 分支(或你的預設分支)、資料夾選擇 `/ (root)`
5. 按下 Save,等待 1-2 分鐘,GitHub 會提供一個網址：
   ```
   https://<你的帳號>.github.io/<repo名稱>/
   ```

## 本機預覽

直接用瀏覽器打開 `index.html` 即可,不需要任何伺服器或建置步驟(純 HTML/CSS/JS,無外部相依套件)。
